import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 * @User: Qushao
 * @DateTime: 2022/10/25 15:35
 * @Description:
 **/
public class Producer_HelloWorld {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("49.233.252.122");
        connectionFactory.setPort(5672);
        connectionFactory.setVirtualHost("/");
        connectionFactory.setUsername("admin");
        connectionFactory.setPassword("admin");
        Connection connection = connectionFactory.newConnection();
        Channel channel = connection.createChannel();
        channel.queueDeclare("helloWorld", true, false, false, null);
        String body = "Hello World!";
        channel.basicPublish("", "helloWorld", null, body.getBytes());
        channel.close();
        connection.close();
    }
}
