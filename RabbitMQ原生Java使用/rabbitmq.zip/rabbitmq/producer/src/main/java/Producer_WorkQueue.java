import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

/**
 * @User: Qushao
 * @DateTime: 2022/10/25 15:35
 * @Description:
 **/
public class Producer_WorkQueue {
    public static void main(String[] args) throws IOException, TimeoutException {
        ConnectionFactory connectionFactory = new ConnectionFactory();
        connectionFactory.setHost("49.233.252.122");
        connectionFactory.setPort(5672);
        connectionFactory.setVirtualHost("/");
        connectionFactory.setUsername("admin");
        connectionFactory.setPassword("admin");
        Connection connection = connectionFactory.newConnection();
        Channel channel = connection.createChannel();
        channel.queueDeclare("workQueue", true, false, false, null);
        for (int i = 0; i < 20; i++) {
            String body = i + " Work Queue!";
            channel.basicPublish("", "workQueue", null, body.getBytes());
        }
        channel.close();
        connection.close();
    }
}
