package com.example.demo.service;

/**
 * @Description
 * @Author
 * @Date 2023/12/15
 */
public interface TestService {
    String test() throws Exception;

    void createIndex();

    void createDocument();

    void updateDocument();

    void boolQueryDocument();

    void matchQueryDocument();
}
