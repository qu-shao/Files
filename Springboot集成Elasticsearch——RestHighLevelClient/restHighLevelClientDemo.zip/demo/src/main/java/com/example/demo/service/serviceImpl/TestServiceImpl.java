package com.example.demo.service.serviceImpl;

import com.example.demo.service.TestService;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.action.update.UpdateResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.client.indices.CreateIndexRequest;
import org.elasticsearch.client.indices.CreateIndexResponse;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * @Description
 * @Author
 * @Date 2023/12/15
 */
@Service
public class TestServiceImpl implements TestService {
    private final RestHighLevelClient restHighLevelClient;

    public TestServiceImpl(RestHighLevelClient restHighLevelClient) {
        this.restHighLevelClient = restHighLevelClient;
    }

    @Override
    public String test() throws Exception {
        return null;
    }

    @Override
    public void createIndex() {
        CreateIndexRequest request = new CreateIndexRequest("test");
        request.settings(Settings.builder()
                .put("index.number_of_shards", 3)
                .put("index.number_of_replicas", 0)
                .put("analysis.analyzer", "ik_smart")
        );
        Map<String, Object> name = new HashMap<>();
        name.put("type", "keyword");
        name.put("ignore_above", 256);
        Map<String, Object> sex = new HashMap<>();
        sex.put("type", "integer");
        sex.put("index", "false");
        Map<String, Object> introduce = new HashMap<>();
        introduce.put("type", "text");
        introduce.put("analyzer", "ik_max_word");
        Map<String, Object> birthday = new HashMap<>();
        birthday.put("type", "date");
        Map<String, Object> properties = new HashMap<>();
        properties.put("name", name);
        properties.put("sex", sex);
        properties.put("introduce", introduce);
        properties.put("birthday", birthday);
        Map<String, Object> mapping = new HashMap<>();
        mapping.put("properties", properties);
        request.mapping(mapping);

        try {
            CreateIndexResponse createIndexResponse = restHighLevelClient.indices().create(request,
                    RequestOptions.DEFAULT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void createDocument() {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("name", "屈少");
        jsonMap.put("birthday", "2000-01-01");
        jsonMap.put("introduce", "他日若遂凌云志，敢笑黄巢不丈夫");
        jsonMap.put("sex", 1);
        IndexRequest indexRequest = new IndexRequest("test")
                .id("001").source(jsonMap);
        try {
            IndexResponse indexResponse = restHighLevelClient.index(indexRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void updateDocument() {
        Map<String, Object> jsonMap = new HashMap<>();
        jsonMap.put("introduce", "天生我材必有用，千金散尽还复来。");
        UpdateRequest request = new UpdateRequest("test", "001")
                .doc(jsonMap);
        try {
            UpdateResponse updateResponse = restHighLevelClient.update(
                    request, RequestOptions.DEFAULT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void boolQueryDocument() {
        SearchRequest searchRequest = new SearchRequest().indices("test").types("_doc");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        BoolQueryBuilder boolQueryBuilder = QueryBuilders.boolQuery();
        boolQueryBuilder.must(QueryBuilders.termQuery("name", "屈少"));
        boolQueryBuilder.must(QueryBuilders.rangeQuery("sex").gte(1).lte(1));
        boolQueryBuilder.should(QueryBuilders.matchPhraseQuery("introduce", "你真棒"));
        searchSourceBuilder.query(boolQueryBuilder);
        searchRequest.source(searchSourceBuilder);
        try {
            SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(searchResponse.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void matchQueryDocument() {
        SearchRequest searchRequest = new SearchRequest().indices("test").types("_doc");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        MatchQueryBuilder matchQueryBuilder = QueryBuilders.matchQuery("introduce", "如果天生我材").minimumShouldMatch("50%");
        searchSourceBuilder.query(matchQueryBuilder);
        searchRequest.source(searchSourceBuilder);
        try {
            SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
            System.out.println(searchResponse.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
