package com.example.demo.controller;

import com.example.demo.service.TestService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Description
 * @Author
 * @Date 2023/12/15
 */
@RestController
public class TestController {
    private final TestService testService;

    public TestController(TestService testService) {
        this.testService = testService;
    }

    @RequestMapping("/test/createIndex")
    public void testCreateIndex() {
        testService.createIndex();
    }

    @RequestMapping("/test/createDocument")
    public void testCreateDocument() {
        testService.createDocument();
    }

    @RequestMapping("/test/updateDocument")
    public void testUpdateDocument() {
        testService.updateDocument();
    }

    @RequestMapping("/test/boolQueryDocument")
    public void testBoolQueryDocument() {
        testService.boolQueryDocument();
    }

    @RequestMapping("/test/matchQueryDocument")
    public void testMatchQueryDocument() {
        testService.matchQueryDocument();
    }
}
