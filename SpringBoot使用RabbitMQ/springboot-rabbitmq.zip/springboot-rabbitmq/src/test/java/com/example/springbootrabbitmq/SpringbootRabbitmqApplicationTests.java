package com.example.springbootrabbitmq;

import com.example.springbootrabbitmq.Producer.PubSub.PubSubRabbitMQConfig;
import com.example.springbootrabbitmq.Producer.Routing.RoutingRabbitMQConfig;
import com.example.springbootrabbitmq.Producer.Simple.SimpleRabbitMQConfig;
import com.example.springbootrabbitmq.Producer.Topics.TopicsRabbitMQConfig;
import com.example.springbootrabbitmq.Producer.WorkQueue.WorkRabbitMQConfig;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqApplicationTests {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Test
    public void testSimpleSend(){
        for (int i = 1; i < 21; i++) {
            String message = "Simple message : " + i;
            rabbitTemplate.convertAndSend(SimpleRabbitMQConfig.QUEUE_NAME, message);
        }
    }

    @Test
    public void testWorkSend(){
        for (int i = 1; i < 21; i++) {
            String message = "Work queue message : " + i;
            rabbitTemplate.convertAndSend(WorkRabbitMQConfig.QUEUE_NAME, message);
        }
    }

    @Test
    public void testPubSubSend(){
        rabbitTemplate.convertAndSend(PubSubRabbitMQConfig.EXCHANGE_NAME, "", "pubsub message one");
        rabbitTemplate.convertAndSend(PubSubRabbitMQConfig.EXCHANGE_NAME, "", "pubsub message two");
        rabbitTemplate.convertAndSend(PubSubRabbitMQConfig.EXCHANGE_NAME, "", "pubsub message three");
    }

    @Test
    public void testRoutingSend(){
        rabbitTemplate.convertAndSend(RoutingRabbitMQConfig.EXCHANGE_NAME, "error", "routing error message");
        rabbitTemplate.convertAndSend(RoutingRabbitMQConfig.EXCHANGE_NAME, "info", "routing info message");
        rabbitTemplate.convertAndSend(RoutingRabbitMQConfig.EXCHANGE_NAME, "warning", "routing warning message");
    }

    @Test
    public void testTopicSend(){
        rabbitTemplate.convertAndSend(TopicsRabbitMQConfig.EXCHANGE_NAME, ".orange.", "topic message one");
        rabbitTemplate.convertAndSend(TopicsRabbitMQConfig.EXCHANGE_NAME, "..rabbit", "topic message two");
        rabbitTemplate.convertAndSend(TopicsRabbitMQConfig.EXCHANGE_NAME, "lazy.", "topic message two");
    }
}
