package com.example.springbootrabbitmq.Producer.Simple;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 20:37
 * @Description:
 **/
@Configuration
public class SimpleRabbitMQConfig {
    public static final String QUEUE_NAME = "boot_simple_queue";

    @Bean("bootSimpleQueue")
    Queue bootSimpleQueue(){
        return QueueBuilder.durable(QUEUE_NAME).build();
    }
}
