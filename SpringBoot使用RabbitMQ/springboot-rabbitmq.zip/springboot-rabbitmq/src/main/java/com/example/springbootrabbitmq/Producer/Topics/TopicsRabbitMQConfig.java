package com.example.springbootrabbitmq.Producer.Topics;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 20:37
 * @Description:
 **/
@Configuration
public class TopicsRabbitMQConfig {
    public static final String EXCHANGE_NAME = "boot_topic_exchange";
    public static final String QUEUE_NAME_ONE = "boot_topic_queue_one";
    public static final String QUEUE_NAME_TWO = "boot_topic_queue_two";

    @Bean("bootTopicExchange")
    public Exchange bootTopicExchange() {
        return ExchangeBuilder.topicExchange(EXCHANGE_NAME).durable(true).build();
    }

    @Bean("bootTopicQueueOne")
    public Queue bootTopicQueueOne() {
        return QueueBuilder.durable(QUEUE_NAME_ONE).build();
    }

    @Bean("bootTopicQueueTwo")
    public Queue bootTopicQueueTwo() {
        return QueueBuilder.durable(QUEUE_NAME_TWO).build();
    }

    @Bean("bindTopicExchangeOne")
    public Binding bindTopicExchangeOne(@Qualifier("bootTopicQueueOne") Queue queue, @Qualifier("bootTopicExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("*.orange.*").noargs();
    }

    @Bean("bindTopicExchangeTwo")
    public Binding bindTopicExchangeTwo(@Qualifier("bootTopicQueueTwo") Queue queue, @Qualifier("bootTopicExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("*.*.rabbit").noargs();
    }

    @Bean("bindTopicExchangeThree")
    public Binding bindTopicExchangeThree(@Qualifier("bootTopicQueueTwo") Queue queue, @Qualifier("bootTopicExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("lazy.#").noargs();
    }
}
