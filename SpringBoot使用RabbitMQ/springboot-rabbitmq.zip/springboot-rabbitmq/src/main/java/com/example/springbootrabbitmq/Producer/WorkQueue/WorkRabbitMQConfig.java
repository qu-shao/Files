package com.example.springbootrabbitmq.Producer.WorkQueue;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 20:37
 * @Description:
 **/
@Configuration
public class WorkRabbitMQConfig {
    public static final String QUEUE_NAME = "boot_work_queue";

    @Bean("bootWorkQueue")
    public Queue bootWorkQueue() {
        return QueueBuilder.durable(QUEUE_NAME).build();
    }
}
