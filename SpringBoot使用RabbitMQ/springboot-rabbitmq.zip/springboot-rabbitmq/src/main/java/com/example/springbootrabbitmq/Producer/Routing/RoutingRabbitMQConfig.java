package com.example.springbootrabbitmq.Producer.Routing;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 20:37
 * @Description:
 **/
@Configuration
public class RoutingRabbitMQConfig {
    public static final String EXCHANGE_NAME = "boot_routing_exchange";
    public static final String QUEUE_NAME_ONE = "boot_routing_queue_one";
    public static final String QUEUE_NAME_TWO = "boot_routing_queue_two";

    @Bean("bootRoutingExchange")
    public Exchange bootRoutingExchange() {
        return ExchangeBuilder.directExchange(EXCHANGE_NAME).durable(true).build();
    }

    @Bean("bootRoutingQueueOne")
    public Queue bootRoutingQueueOne() {
        return QueueBuilder.durable(QUEUE_NAME_ONE).build();
    }

    @Bean("bootRoutingQueueTwo")
    public Queue bootRoutingQueueTwo() {
        return QueueBuilder.durable(QUEUE_NAME_TWO).build();
    }

    @Bean("bindRoutingExchangeErrorToOne")
    public Binding bindRoutingExchangeErrorToOne(@Qualifier("bootRoutingQueueOne") Queue queue, @Qualifier("bootRoutingExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("error").noargs();
    }

    @Bean("bindRoutingExchangeInfoToTwo")
    public Binding bindRoutingExchangeInfoToTwo(@Qualifier("bootRoutingQueueTwo") Queue queue, @Qualifier("bootRoutingExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("info").noargs();
    }

    @Bean("bindRoutingExchangeErrorToTwo")
    public Binding bindRoutingExchangeErrorToTwo(@Qualifier("bootRoutingQueueTwo") Queue queue, @Qualifier("bootRoutingExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("error").noargs();
    }

    @Bean("bindRoutingExchangeWarningToTwo")
    public Binding bindRoutingExchangeWarningToTwo(@Qualifier("bootRoutingQueueTwo") Queue queue, @Qualifier("bootRoutingExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("warning").noargs();
    }
}
