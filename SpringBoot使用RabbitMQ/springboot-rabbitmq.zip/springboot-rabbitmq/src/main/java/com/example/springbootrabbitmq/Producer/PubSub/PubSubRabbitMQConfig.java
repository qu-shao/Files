package com.example.springbootrabbitmq.Producer.PubSub;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 20:37
 * @Description:
 **/
@Configuration
public class PubSubRabbitMQConfig {
    public static final String EXCHANGE_NAME = "boot_pubsub_exchange";
    public static final String QUEUE_NAME_ONE = "boot_pubsub_queue_one";
    public static final String QUEUE_NAME_TWO = "boot_pubsub_queue_two";

    @Bean("bootPubSubExchange")
    public Exchange bootPubSubExchange() {
        return ExchangeBuilder.fanoutExchange(EXCHANGE_NAME).durable(true).build();
    }

    @Bean("bootPubSubQueueOne")
    public Queue bootPubSubQueueOne() {
        return QueueBuilder.durable(QUEUE_NAME_ONE).build();
    }

    @Bean("bootPubSubQueueTwo")
    public Queue bootPubSubQueueTwo() {
        return QueueBuilder.durable(QUEUE_NAME_TWO).build();
    }

    @Bean("bindPubSubQueueOne")
    public Binding bindPubSubQueueOne(@Qualifier("bootPubSubQueueOne") Queue queue, @Qualifier("bootPubSubExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("").noargs();
    }

    @Bean("bindPubSubQueueTwo")
    public Binding bindPubSubQueueTwo(@Qualifier("bootPubSubQueueTwo") Queue queue, @Qualifier("bootPubSubExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("").noargs();
    }
}
