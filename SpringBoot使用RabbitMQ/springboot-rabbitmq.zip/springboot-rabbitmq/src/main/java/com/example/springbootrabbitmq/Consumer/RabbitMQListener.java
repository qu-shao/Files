package com.example.springbootrabbitmq.Consumer;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @User: Qushao
 * @DateTime: 2022/10/27 22:30
 * @Description:
 **/
@Component
public class RabbitMQListener {

    @RabbitListener(queues = "boot_simple_queue")
    public void SimpleListener(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Simple mode : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_work_queue")
    public void WorkListenerOne(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Work mode, by consumer one : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_work_queue")
    public void WorkListenerTwo(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Work mode, by consumer two : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_pubsub_queue_one")
    public void PubSubListenerOne(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("PubSub mode, by consumer one : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_pubsub_queue_two")
    public void PubSubListenerTwo(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("PubSub mode, by consumer two : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_routing_queue_one")
    public void RoutingListenerOne(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Routing mode, by consumer one : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_routing_queue_two")
    public void RoutingListenerTwo(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Routing mode, by consumer two : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_topic_queue_one")
    public void TopicsListenerOne(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Topic mode, by consumer one : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }

    @RabbitListener(queues = "boot_topic_queue_two")
    public void TopicsListenerTwo(Message message) {
        try {
            BufferedWriter out = new BufferedWriter(new FileWriter("result.txt", true));
            out.write("Topic mode, by consumer two : " + new String(message.getBody()) + "\n");
            out.close();
        } catch (IOException e) {
        }
    }
}
