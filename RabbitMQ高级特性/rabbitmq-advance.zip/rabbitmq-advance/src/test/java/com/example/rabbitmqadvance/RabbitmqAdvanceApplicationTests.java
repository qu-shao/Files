package com.example.rabbitmqadvance;

import org.junit.jupiter.api.Test;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessagePostProcessor;
import org.springframework.amqp.core.ReturnedMessage;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitmqAdvanceApplicationTests {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Test
    public void testReliabilityQos(){
        for (int i = 0; i < 10; i++) {
            String s = "Reliability test: Qos! " + i;
            rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME, "reliability", s);
        }
    }

    @Test
    public void testReliabilityConfirm() throws InterruptedException {
        String s = "Reliability test: Confirm!";
        rabbitTemplate.setConfirmCallback(new RabbitTemplate.ConfirmCallback() {
            @Override
            public void confirm(CorrelationData correlationData, boolean ack, String cause) {
                System.out.println("ConfirmBack 方法执行");
                if(ack){
                    System.out.println("接收成功");
                }else{
                    System.out.println(cause);
                }
            }
        });

        rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME, "reliability", s);
        Thread.sleep(0xc8);
    }

    @Test
    public void testReliabilityReturn() throws InterruptedException {
        String s = "Reliability test: Return!";
        rabbitTemplate.setMandatory(true);
        rabbitTemplate.setReturnsCallback(new RabbitTemplate.ReturnsCallback() {
            @Override
            public void returnedMessage(ReturnedMessage returned) {
                System.out.println("ReturnCallBack方法执行了");
                System.out.println("Message: " + new String(returned.getMessage().getBody()));
                System.out.println("ReplyCode: " + returned.getReplyCode());
                System.out.println("ReplyText: " + returned.getReplyText());
                System.out.println("Exchange: " + returned.getExchange());
                System.out.println("RoutingKey: " + returned.getRoutingKey());
            }
        });
        rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME, "wrongRoutingKey", s);
        Thread.sleep(0xc8);
    }

    @Test
    public void testTTLQueue(){
        for (int i = 0; i < 10; i++) {
            String s = "Test TTL, Queue! " + i;
            rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME_TTL, "reliabilityTTL", s);
        }
    }

    @Test
    public void testTTLMessage(){
        String s = "Test TTL, Single Message!";
        rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME_TTL, "reliabilityTTL", s, new MessagePostProcessor() {
            @Override
            public Message postProcessMessage(Message message) throws AmqpException {
                message.getMessageProperties().setExpiration("5000");
                return message;
            }
        });
    }

    @Test
    public void testDLX() throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            String s = "Test DLX, Message!";
            rabbitTemplate.convertAndSend(ReliabilityConfig.EXCHANGE_NAME_NORMAL, "reliabilitynormal", s);
        }
    }
}
