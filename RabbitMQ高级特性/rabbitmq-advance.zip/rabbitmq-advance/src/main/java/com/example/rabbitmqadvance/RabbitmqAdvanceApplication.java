package com.example.rabbitmqadvance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitmqAdvanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(RabbitmqAdvanceApplication.class, args);
    }

}
