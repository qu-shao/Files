package com.example.rabbitmqadvance;

import com.rabbitmq.client.Channel;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.listener.api.ChannelAwareMessageListener;
import org.springframework.stereotype.Component;

/**
 * @User: Qushao
 * @DateTime: 2022/10/29 18:41
 * @Description:
 **/
@Component
public class ConsumerAckListener implements ChannelAwareMessageListener {

    @Override
    @RabbitListener(queues = "test_reliability_queue")
    public void onMessage(Message message, Channel channel) throws Exception {
        long deliveryTag = message.getMessageProperties().getDeliveryTag();
        try {
            System.out.println(new String(message.getBody()));
            System.out.println("业务逻辑");
//            int i = 3/0;
            channel.basicAck(deliveryTag, true);
        } catch (Exception e) {
            channel.basicNack(deliveryTag, true, true);
        }
    }
}
