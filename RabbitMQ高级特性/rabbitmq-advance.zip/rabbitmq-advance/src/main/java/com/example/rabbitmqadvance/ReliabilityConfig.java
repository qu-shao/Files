package com.example.rabbitmqadvance;

import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * @User: Qushao
 * @DateTime: 2022/10/28 13:49
 * @Description:
 **/
@Configuration
public class ReliabilityConfig {
    public static final String QUEUE_NAME = "test_reliability_queue";
    public static final String QUEUE_NAME_TTL = "test_ttl_queue";
    public static final String QUEUE_NAME_NORMAL = "test_reliability_queue_normal";
    public static final String QUEUE_NAME_DLX = "test_dlx_queue";
    public static final String EXCHANGE_NAME = "test_reliability_queue";

    public static final String EXCHANGE_NAME_TTL = "test_reliability_queue_ttl";
    public static final String EXCHANGE_NAME_NORMAL = "test_reliability_queue_normal";
    public static final String EXCHANGE_NAME_DLX = "test_reliability_queue_dlx";

    @Bean("reliabilityQueue")
    public Queue reliabilityQueue() {
        return QueueBuilder.durable(QUEUE_NAME).build();
    }

    @Bean("reliabilityExchange")
    public DirectExchange reliabilityExchange() {
        return ExchangeBuilder.directExchange(EXCHANGE_NAME).durable(true).build();
    }

    @Bean("bindReliabilityExchange")
    public Binding bindReliabilityExchange(@Qualifier("reliabilityQueue") Queue queue, @Qualifier("reliabilityExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("reliability").noargs();
    }

    @Bean("reliabilityQueueTTL")
    public Queue reliabilityQueueTTL() {
        return QueueBuilder.durable(QUEUE_NAME_TTL).ttl(5000).build();
    }

    @Bean("reliabilityTTLExchange")
    public DirectExchange reliabilityTTLExchange() {
        return ExchangeBuilder.directExchange(EXCHANGE_NAME_TTL).durable(true).build();
    }

    @Bean("bindReliabilityTTLExchange")
    public Binding bindReliabilityTTLExchange(@Qualifier("reliabilityQueueTTL") Queue queue, @Qualifier("reliabilityTTLExchange") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("reliabilityTTL").noargs();
    }

    // 声明死信队列
    @Bean("reliabilityQueueDLX")
    public Queue reliabilityQueueDLX() {
        return QueueBuilder.durable(QUEUE_NAME_DLX).build();
    }

    // 声明死信交换机
    @Bean("reliabilityExchangeDLX")
    public DirectExchange reliabilityExchangeDLX() {
        return ExchangeBuilder.directExchange(EXCHANGE_NAME_DLX).durable(true).build();
    }

    // 死信队列绑定死信交换机
    @Bean("bindReliabilityExchangeDLX")
    public Binding bindReliabilityExchangeDLX(@Qualifier("reliabilityQueueDLX") Queue queue, @Qualifier("reliabilityExchangeDLX") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("reliabilityDLX").noargs();
    }

    // 声明正常队列
    @Bean("reliabilityQueueNormal")
    public Queue reliabilityQueueNormal() {
        Map<String, Object> arguments = new HashMap<>(2);
        // 绑定该队列到死信交换机
        arguments.put("x-dead-letter-exchange", EXCHANGE_NAME_DLX);
        arguments.put("x-dead-letter-routing-key", "reliabilityDLX");
        return QueueBuilder.durable(QUEUE_NAME_NORMAL).ttl(5000).withArguments(arguments).build();
    }

    // 声明正常交换机
    @Bean("reliabilityExchangeNormal")
    public DirectExchange reliabilityExchangeNormal() {
        return ExchangeBuilder.directExchange(EXCHANGE_NAME_NORMAL).durable(true).build();
    }

    // 正常队列绑定正常交换机
    @Bean("bindReliabilityExchangeNormal")
    public Binding bindReliabilityExchangeNormal(@Qualifier("reliabilityQueueNormal") Queue queue, @Qualifier("reliabilityExchangeNormal") Exchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with("reliabilitynormal").noargs();
    }
}
