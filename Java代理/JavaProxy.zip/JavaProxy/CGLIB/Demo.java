package DesignPattern.Proxy.CGLIB;

import net.sf.cglib.proxy.Enhancer;

/**
 * @User: Qushao
 * @DateTime: 2022/11/19 11:19
 * @Description:
 **/
public class Demo {
    public static void main(String[] args) {
        Enhancer enhancer = new Enhancer();
        enhancer.setSuperclass(Draw.class);
        enhancer.setCallback(new TimeMethodInterceptor());
        Draw draw = (Draw) enhancer.create();
        draw.doFunction();
    }
}
