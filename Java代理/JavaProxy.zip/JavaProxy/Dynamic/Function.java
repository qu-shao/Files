package DesignPattern.Proxy.Dynamic;

public interface Function {
    void doFunction();
}
