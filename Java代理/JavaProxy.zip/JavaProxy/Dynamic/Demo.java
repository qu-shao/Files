package DesignPattern.Proxy.Dynamic;


import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * @User: Qushao
 * @DateTime: 2022/11/18 20:25
 * @Description:
 **/
public class Demo {
    public static void main(String[] args) {
        System.getProperties().put("jdk.proxy.ProxyGenerator.saveGeneratedFiles", "true");
        Draw draw = new Draw();
        Function f = (Function) Proxy.newProxyInstance(draw.getClass().getClassLoader(),
                new Class[]{Function.class},
                new InvocationHandler() {
                    @Override
                    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                        System.out.println("method: " + method.getName() + " start... ...");
                        Object o = method.invoke(draw, args);
                        System.out.println("method: " + method.getName() + " end!");
                        return o;
                    }
                });
        f.doFunction();
    }
}
