package DesignPattern.Proxy.Static;

/**
 * @User: Qushao
 * @DateTime: 2022/11/18 20:28
 * @Description:
 **/
public class TimeProxy implements Function{
    private Function function;
    public TimeProxy(Function function){
        this.function = function;
    }

    @Override
    public void doFunction() {
        long start = System.currentTimeMillis();
        function.doFunction();
        long end = System.currentTimeMillis();
        System.out.println(end - start);
    }
}
