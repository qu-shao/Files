package DesignPattern.Proxy.Static;

public interface Function {
    void doFunction();
}
