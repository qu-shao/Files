package DesignPattern.Proxy.Static;

/**
 * @User: Qushao
 * @DateTime: 2022/11/18 20:27
 * @Description:
 **/
public class Draw implements Function{
    @Override
    public void doFunction() {
        System.out.println("Draw a picture!");
    }
}
