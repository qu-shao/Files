package DesignPattern.Proxy.Static;

import java.sql.Time;

/**
 * @User: Qushao
 * @DateTime: 2022/11/18 20:25
 * @Description:
 **/
public class Demo {
    public static void main(String[] args) {
        new TimeProxy(new Draw()).doFunction();
    }
}
